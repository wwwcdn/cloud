function show_read(){
document.writeln("<div align=center style=\'FONT-SIZE:14pt;color:#FF0000;\'><b>����������ַ��www.kknn.net</b></div>");
}

function read_tool(){


document.writeln("<SCRIPT language=JavaScript src=\"https://cssjs.lisawuwa.com/public/cssjs/tool.js\"></SCRIPT>");


//
document.writeln("<style>");document.writeln(".skin0 {");document.writeln("	DISPLAY: none; WIDTH: 180px; CURSOR: default; FONT-FAMILY: Verdana; POSITION: absolute");document.writeln("}");document.writeln(".skin1 {");document.writeln("	BORDER-RIGHT: 1px outset; BORDER-TOP: 1px outset; BORDER-LEFT: 1px outset; WIDTH: 180px; CURSOR: default; BORDER-BOTTOM: 1px outset; POSITION: absolute");document.writeln("}");document.writeln(".menuitems {");document.writeln("	PADDING-LEFT: 6px; FONT-SIZE: 12px; PADDING-BOTTOM: 0px; MARGIN: 1px 3px; PADDING-TOP: 2px");document.writeln("}");document.writeln(".itemshovor {");document.writeln("	BORDER-RIGHT: darkblue 1px outset; BORDER-TOP: darkblue 1px outset; PADDING-LEFT: 6px; FONT-SIZE: 12px; Z-INDEX: 7; PADDING-BOTTOM: 0px; MARGIN: 1px 3px; BORDER-LEFT: darkblue 1px outset; PADDING-TOP: 0px; BORDER-BOTTOM: darkblue 1px outset; POSITION: relative; BACKGROUND-COLOR: lightsteelblue");document.writeln("}");document.writeln(".side {");document.writeln("	Z-INDEX: 866; FILTER: Alpha(Opacity= \"40\" ,FinishOpacity= \"95\" ,Style= \"1\" ); WIDTH: 30px; POSITION: absolute ;left: 0px;; HEIGHT: 195px; BACKGROUND-COLOR: lightblue");document.writeln("}");document.writeln(".hr {");document.writeln("	PADDING-RIGHT: 5px; PADDING-LEFT: 25px; size: 1px");document.writeln("}");document.writeln("IMG {");document.writeln("	BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none");document.writeln("}");document.writeln("<\/style>")
document.writeln("<DIV id=ie5menu style=\"BORDER-RIGHT: #9bc9df 1px solid; BORDER-TOP: #9bc9df 1px solid; DISPLAY: none; Z-INDEX: 99999; BORDER-LEFT: #9bc9df 1px solid; BORDER-BOTTOM: #9bc9df 1px solid; POSITION: absolute; BACKGROUND-COLOR: white\">");document.writeln("<DIV class=side><\/DIV>");document.writeln("");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><A href=\""+next_page+"\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/next.gif\" width=12 border=0>&nbsp;&nbsp;��һҳ&nbsp;&nbsp;&nbsp;<\/A> <\/DIV>");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><A href=\""+preview_page+"\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/pre.gif\" width=12 border=0>&nbsp;&nbsp;��һҳ&nbsp;&nbsp;&nbsp;<\/A> <\/DIV>");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><A href=\""+index_page+"\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/back_items.gif\" width=12 border=0>&nbsp;&nbsp;����Ŀ&nbsp;&nbsp;&nbsp;<\/A> <\/DIV>");document.writeln("");document.writeln("<DIV class=hr><HR color=#9bc9df SIZE=1><\/DIV>");document.writeln("");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><A onclick=\"window.location.reload(); return false;\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/refresh.gif\" width=12 border=0>&nbsp;&nbsp;ˢ��&nbsp;&nbsp;&nbsp;<\/A> <\/DIV>");document.writeln("<DIV class=menuitems onmouseover=myover(this); onclick=javascript:window.print(); onmouseout=myout(this);><A onclick=\"javascript:window.print(); return false;\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/print.gif\" width=12 border=0>&nbsp;&nbsp;��ӡ&nbsp;&nbsp;&nbsp;<\/A> <\/DIV>");document.writeln("");document.writeln("<DIV class=hr><HR color=#9bc9df SIZE=1><\/DIV>");document.writeln("");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><a href=\"javascript:showpop('\/modules\/article\/uservote.php?id="+bookid+"&ajax_request=1');\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/advise.gif\" width=12 border=0>&nbsp;&nbsp;�Ƽ�����&nbsp;&nbsp;&nbsp;<\/A> <\/DIV>");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><a href=\"javascript:showpop('\/modules\/article\/addbookcase.php?id="+bookid+"&cid="+contentid+"&ajax_request=1');\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/add_book.gif\" width=12 border=0>&nbsp;&nbsp;������ǩ&nbsp;&nbsp;&nbsp;<\/A><\/DIV>");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><A href=\"./"+ bookid+"/\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/back_book.gif\" width=12 border=0>&nbsp;&nbsp;������ҳ&nbsp;&nbsp;&nbsp;<\/A><\/DIV>");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><A href=\"\/\"><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/back_home.gif\" width=12 border=0>&nbsp;&nbsp;������ҳ&nbsp;&nbsp;&nbsp;<\/A><\/DIV>");document.writeln("");document.writeln("<DIV class=hr><HR color=#9bc9df SIZE=1><\/DIV>");document.writeln("");document.writeln("<DIV class=menuitems onmouseover=myover(this); onmouseout=myout(this);><A href=\"\/register.html\" target=_blank><IMG height=15 src=\"https://cssjs.lisawuwa.com\/images\/vip.gif\" width=12 border=0>&nbsp;&nbsp;ע���Ա&nbsp;&nbsp;&nbsp;<\/A> <\/DIV>");document.writeln("<\/DIV>")
var menuskin=1
var display_url=0
function showmenuie5(event)
{event=event?event:(window.event?window.event:null);var menu=$("ie5menu");menu.style.display="";var rightedge=document.body.clientWidth-event.clientX;var bottomedge=document.body.clientHeight-event.clientY;if(rightedge<menu.offsetWidth)
{menu.style.left=document.body.scrollLeft+event.clientX-menu.offsetWidth;}
else
{menu.style.left=document.body.scrollLeft+event.clientX;}
if(bottomedge<menu.offsetHeight)
{menu.style.top=document.body.scrollTop+event.clientY-menu.offsetHeight;}
else
{menu.style.top=document.body.scrollTop+event.clientY;}
return false;}
function hidemenuie5()
{var menu=$("ie5menu");menu.style.display="none"}
function myover(obj)
{obj.className="itemshovor";}
function myout(obj)
{obj.className="menuitems";}
function $(objName)
{if(document.getElementById)
{return document.getElementById(objName);}
else if(document.layers)
{return eval("document.layers['"+ objName+"']");}
else
{return eval('document.all.'+ objName);}}
if(menuskin==0)
ie5menu.className="skin0"
else
ie5menu.className="skin1"
if(document.all)
{document.oncontextmenu=showmenuie5;}
else
{document.oncontextmenu=function(event){return showmenuie5(event);}}
document.body.onclick=hidemenuie5

}

function read_select_do(){
document.writeln("<div align=center style=\'FONT-SIZE:14pt;color:#FF0000;\'><b>����������ַ��www.kknn.net</b></div>");
}

function bottom_tongji(){
//shujia


document.writeln("<div align=center style=\'padding-top:10px;FONT-SIZE:10pt;color:#777777;\'><strong><p>������ѧ�ϵ�����С˵�鼮��Ϊת����Ʒ�������½��������ϴ���ת������վֻ��Ϊ�����������ø���������͡�</p>");
document.writeln("<p>�����緢����Ʒ���ݻ����ۺ����ɵִ����ַ�����Ȩ������Ϊ,�����������žٱ�,��վ�������Դ�����</p></strong></div>");

document.writeln("<script type=\"text/javascript\" src=\"https://cssjs.lisawuwa.com/public/cssjs/count.js\"></script>");
}
